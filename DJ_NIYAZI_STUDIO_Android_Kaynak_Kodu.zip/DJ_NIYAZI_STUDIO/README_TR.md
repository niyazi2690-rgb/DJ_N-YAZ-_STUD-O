# DJ NIYAZI STUDIO 1.0 — Android proje başlangıcı

Bu paket, DJ NIYAZI STUDIO için yerel Android kaynak kodu başlangıç projesidir.

## İçindekiler
- Koyu temalı profesyonel stüdyo arayüzü
- 16 adımlı Kick / Snare / Hi-hat / Bass ritim sequencer
- BPM kontrolü
- Dokunmatik sanal piyano
- Telefon üzerinde çevrimdışı çalışan basit sentez sesleri

## Önemli
Bu paket **kaynak kodudur, APK değildir**. APK üretmek için Android SDK ve JDK 17 ile Gradle derlemesi gerekir. Bu ilk sürümde AI şarkı üretimi, vokal kayıt, gerçek enstrüman örnekleri ve MP3/WAV dışa aktarma henüz eklenmemiştir. Bunlar sonraki geliştirme adımlarıdır.

## Derleme
Android Studio bulunan bir bilgisayarda:
1. ZIP dosyasını çıkarın.
2. Android Studio ile `DJ_NIYAZI_STUDIO` klasörünü açın.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. Build > Build APK(s) seçin.

Sadece Android telefon kullanıyorsanız, bu proje dosyalarını destekleyen bir Android bulut geliştirme/derleme ortamına yüklemek gerekir. Telefonun kendisi tek başına Android SDK/Gradle kurulu değilse APK derleyemez.

## Teknik
- Kotlin
- Jetpack Compose
- Minimum Android 8.0 (API 26)
- Harici servis gerektirmeyen temel ritim ve piyano sesi
