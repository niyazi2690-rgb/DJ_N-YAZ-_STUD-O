package com.djniyazi.studio

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

private val Bg = Color(0xFF10111B)
private val Panel = Color(0xFF1D2030)
private val Purple = Color(0xFFAD5CFF)
private val Muted = Color(0xFFAAAFC5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioScreen() }
    }
}

@Composable
fun StudioScreen() {
    var bpm by remember { mutableFloatStateOf(110f) }
    var playing by remember { mutableStateOf(false) }
    var step by remember { mutableIntStateOf(0) }
    var selectedTab by remember { mutableStateOf("BEAT") }
    val tracks = remember {
        mutableStateListOf(
            mutableStateListOf(1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0),
            mutableStateListOf(0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0),
            mutableStateListOf(1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0),
            mutableStateListOf(1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0)
        )
    }
    val names = listOf("KICK", "SNARE", "HI-HAT", "BASS")

    LaunchedEffect(playing, bpm) {
        while (playing) {
            val currentStep = step
            if (tracks[0][currentStep] == 1) playTone(72.0, 0.13)
            if (tracks[1][currentStep] == 1) playTone(185.0, 0.10)
            if (tracks[2][currentStep] == 1) playTone(1100.0, 0.045)
            if (tracks[3][currentStep] == 1) playTone(55.0, 0.18)
            step = (step + 1) % 16
            delay((60000f / bpm / 4f).toLong().coerceAtLeast(40L))
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Bg, surface = Panel,
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("DJ NIYAZI", fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("MUSIC PRODUCTION STUDIO", color = Purple, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Text("1.0", color = Color.White, modifier = Modifier.background(Purple, RoundedCornerShape(9.dp)).padding(12.dp), fontWeight = FontWeight.Bold)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("BEAT", "PIANO").forEach { tab ->
                    Button(
                        onClick = { selectedTab = tab },
                        colors = ButtonDefaults.buttonColors(containerColor = if (selectedTab == tab) Purple else Panel),
                        modifier = Modifier.weight(1f)
                    ) { Text(tab) }
                }
            }

            if (selectedTab == "BEAT") {
                StudioCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("TEMPO", fontWeight = FontWeight.Bold)
                        Text("${bpm.toInt()} BPM", color = Purple, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = bpm, onValueChange = { bpm = it }, valueRange = 60f..180f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { playing = !playing }, modifier = Modifier.weight(1f)) {
                            Text(if (playing) "Ⅱ DURAKLAT" else "▶ BAŞLAT")
                        }
                        OutlinedButton(onClick = { playing = false; step = 0 }, modifier = Modifier.weight(1f)) { Text("■ DURDUR") }
                    }
                }
                StudioCard {
                    Text("16 ADIM RİTİM MAKİNESİ", fontWeight = FontWeight.Bold)
                    Text("Aktif adım: ${step + 1}", color = Muted, fontSize = 12.sp)
                    names.forEachIndexed { row, name ->
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(name, color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                (0 until 16).forEach { col ->
                                    val active = tracks[row][col] == 1
                                    Box(
                                        Modifier.size(width = 30.dp, height = 34.dp)
                                            .background(
                                                if (col == step && playing) Color.White
                                                else if (active) Purple else Color(0xFF35384C),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .clickable {
                                                tracks[row][col] = if (active) 0 else 1
                                                if (!active) playTone(if (row == 0) 70.0 else if (row == 1) 180.0 else 850.0 else 110.0, 0.07)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("${col + 1}", fontSize = 10.sp, color = if (col == step && playing) Bg else Color.White)
                                    }
                                }
                            }
                        }
                    }
                    TextButton(onClick = { tracks.forEach { row -> for (i in 0..15) row[i] = 0 } }) { Text("RİTMİ TEMİZLE") }
                }
            } else {
                StudioCard {
                    Text("SANAL PİYANO", fontWeight = FontWeight.Bold)
                    Text("Nota çalmak için tuşlara dokun.", color = Muted, fontSize = 12.sp)
                    val notes = listOf("C4" to 261.63, "D4" to 293.66, "E4" to 329.63, "F4" to 349.23, "G4" to 392.0, "A4" to 440.0, "B4" to 493.88, "C5" to 523.25)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        notes.forEach { (label, freq) ->
                            Box(
                                Modifier.width(52.dp).height(120.dp)
                                    .background(Color(0xFFF2F0F8), RoundedCornerShape(bottomStart = 7.dp, bottomEnd = 7.dp))
                                    .clickable { playTone(freq, 0.45) },
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                Text(label, color = Bg, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                StudioCard {
                    Text("SONRAKİ GELİŞTİRMELER", fontWeight = FontWeight.Bold)
                    Text("• Ses kaydı ve çok kanallı düzenleme\n• Bağlama, keman, org ve kemençe\n• Efektler ve MP3/WAV dışa aktarma\n• İnternet üzerinden AI müzik üretimi", color = Muted, lineHeight = 22.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("DJ NIYAZI STUDIO  •  KENDİ MÜZİĞİNİ ÜRET", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun StudioCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

private fun playTone(frequency: Double, duration: Double) {
    Thread {
        try {
            val sampleRate = 22050
            val count = (sampleRate * duration).toInt()
            val samples = ShortArray(count)
            for (i in samples.indices) {
                val envelope = (1.0 - i.toDouble() / count).coerceIn(0.0, 1.0)
                samples[i] = (sin(2.0 * PI * frequency * i / sampleRate) * Short.MAX_VALUE * 0.18 * envelope).toInt().toShort()
            }
            val track = AudioTrack(
                AudioManager.STREAM_MUSIC, sampleRate,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                samples.size * 2, AudioTrack.MODE_STATIC
            )
            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep((duration * 1000).toLong() + 50)
            track.release()
        } catch (_: Exception) { }
    }.start()
}
